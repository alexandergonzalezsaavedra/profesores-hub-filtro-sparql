import React, { useState } from 'react'
import './App.css';
import Cargando from './assets/Cargando/Cargando';
import ServicioHub from './assets/Servicio/ServicioHub';
import Formulario from './components/Formulario/Formulario';
import Tarjetas from './components/Tarjetas/Tarjetas';

function App() {

    const [profesores, setProfesores] = useState([])
    const [filtroProfesor, setFiltroProfesor] = useState('')
    return (
        <>
            <ServicioHub
                setProfesores={setProfesores}
            />
            {
                (() => {
                    if (profesores.length <= 0) {
                        return (
                            <Cargando />
                        )
                    } else {
                        return (
                            <>
                                <div className="container mt-3">
                                    <h2>Toggleable Pills</h2>
                                    <br />
                                    <ul className="nav nav-pills" role="tablist">
                                        <li className="nav-item">
                                            <a className="nav-link active" data-bs-toggle="pill" href="#home">Home</a>
                                        </li>
                                        <li className="nav-item">
                                            <a className="nav-link" data-bs-toggle="pill" href="#menu1">Menu 1</a>
                                        </li>
                                    </ul>

                                    <div className="tab-content">
                                        <div id="home" className="container tab-pane active">
                                            <br />
                                            <h3>Profesores de carrera</h3>
                                            <Formulario
                                                setFiltroProfesor={setFiltroProfesor}
                                                profesores={profesores}
                                            />
                                            <Tarjetas
                                                filtroProfesor={filtroProfesor}
                                                profesores={profesores}
                                            />
                                        </div>
                                        <div id="menu1" className="container tab-pane fade"><br />
                                            <h3>Menu 1</h3>
                                            <p>Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
                                        </div>
                                    </div>
                                </div>


                            </>
                        )
                    }
                })()
            }
        </>
    );
}

export default App;